<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subscriber extends Model
{
    public function exportColumns(): array
    {
        return  [
            'email',
        ];
    }
}
